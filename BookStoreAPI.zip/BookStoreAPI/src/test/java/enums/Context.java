package enums;

public enum Context {

Book,
USER_ID,
USER_ACCOUNT_RESPONSE,
BOOK_REMOVE_RESPONSE;
}
