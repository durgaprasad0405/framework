package apiEngine.model.requests;

public class ISBN {

	public String isbn;

    public ISBN(String isbn) {
        this.isbn = isbn;
    }
	
	
}
