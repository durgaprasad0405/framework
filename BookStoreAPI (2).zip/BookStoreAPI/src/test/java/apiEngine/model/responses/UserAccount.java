package apiEngine.model.responses;


import java.util.List;
import apiEngine.model.Book;

public class UserAccount {
	public String userId;
    public String username;
    public List<Book> books;
}
