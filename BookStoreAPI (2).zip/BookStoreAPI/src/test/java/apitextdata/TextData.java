package apitextdata;

public class TextData {
	
	public static String USER_ID = "1dd66528-0a75-4278-9e4d-4aee85e442f7";
	public static String USERNAME = "Kanna12846";
	public static String PASSWORD = "Kanna@12";
	public static String BASE_URL = "https://bookstore.toolsqa.com";

}
